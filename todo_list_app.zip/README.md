# To-Do List Application

This is a simple command-line To-Do List application built using Python.

## Features
- Add tasks
- View tasks
- Update tasks
- Mark tasks as completed
- Delete tasks

## How to Run
1. Install Python if not installed.
2. Open terminal or command prompt.
3. Navigate to the folder containing `todo.py`.
4. Run the following command:

```sh
python todo.py
```

## Requirements
- Python 3.x

Enjoy using the To-Do List App!
